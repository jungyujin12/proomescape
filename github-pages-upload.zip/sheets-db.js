(function(){
  const endpoint=()=>String(window.SHEETS_API_URL||'').trim();
  async function request(body){if(!endpoint())throw new Error('온라인 데이터베이스가 아직 연결되지 않았습니다.');const response=await fetch(endpoint(),{method:'POST',headers:{'Content-Type':'text/plain;charset=utf-8'},body:JSON.stringify(body),redirect:'follow'});if(!response.ok)throw new Error('서버에 연결할 수 없습니다.');const result=await response.json();if(!result.ok)throw new Error(result.message||'요청을 처리하지 못했습니다.');return result}
  async function availability(){if(!endpoint())return[];const response=await fetch(`${endpoint()}?action=availability`,{redirect:'follow'});const result=await response.json();if(!result.ok)throw new Error(result.message);return result.reservations||[]}
  window.SheetsDB={isConfigured:()=>!!endpoint(),availability,create:data=>request({action:'create',data}),adminLogin:password=>request({action:'adminLogin',password}),adminList:password=>request({action:'adminList',password}),updateStatus:(password,id,status)=>request({action:'updateStatus',password,id,status}),delete:(password,id)=>request({action:'delete',password,id})};
})();
